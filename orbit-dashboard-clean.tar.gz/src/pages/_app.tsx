// src/pages/_app.tsx
import type { AppProps, NextWebVitalsMetric } from 'next/app'

export default function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />
}

// Sobrescreve o hook interno de métricas
export function reportWebVitals(metric: NextWebVitalsMetric) {
  if (metric && metric.startTime !== undefined) {
    console.log(metric.name, metric.startTime)
  } else {
    // evita erro de undefined
  }
}
