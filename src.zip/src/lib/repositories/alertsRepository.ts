// ============================================================================
// ORBIT · Repository — Alerts (v3.0.0)
//
// v3.0.0 (revisão 14/08/2026):
// - ❌ REMOVIDO: fallback para public.alerts (legacy). orbit.alerts é a
//   única fonte agora — não há mais supabaseLegacy neste arquivo.
// - 🐛 CORRIGIDO: fromOrbitRow() só preenchia 7 dos 14 campos obrigatórios
//   de `Alert` (faltava type, metricName, metricValue, thresholdValue,
//   isResolved, createdAt, action). Isso não compilava contra o `Alert`
//   canônico de orbit.ts — corrigido, mapeamento completo abaixo.
// - 🐛 CORRIGIDO: a versão anterior não tinha `return` depois de montar a
//   query legacy — a função terminava sem devolver nada em caso de falha
//   do orbit.alerts. Como o legacy foi removido, isso deixou de existir;
//   agora o erro do orbit.alerts propaga (throw), e quem chama decide
//   como tratar (ver useAlerts.ts).
// - createdAt PERMANECE string, não Date. orbit.ts documenta isso
//   explicitamente na definição de `Alert` — não converter aqui; quem
//   precisar de Date faz `new Date(alert.createdAt)` na camada de UI.
// - alert_type agora é `AlertType` (9 valores reais de orbit.alert_type no
//   Postgres), não `string` solto.
// ============================================================================

import { supabase } from '@/lib/supabase'
import type { Alert, AlertSeverity, AlertType } from '../../types/alert'

// ── Raw shape from orbit.alerts + orbit.clients JOIN ─────────────────────
interface OrbitAlertRow {
  id: string
  client_id: string
  alert_type: AlertType
  severity: AlertSeverity
  title: string
  description: string | null
  metric_name: string | null
  metric_value: number | null
  threshold_value: number | null
  action_url: string | null
  is_resolved: boolean
  created_at: string // ⚠️ estava faltando nesta interface, mas era selecionado na query
  clients: {
    name: string
    handle: string
  } | null
}

function fromOrbitRow(row: OrbitAlertRow): Alert {
  return {
    id: row.id,
    clientId: row.client_id,
    clientName: row.clients?.name ?? '',
    clientHandle: row.clients?.handle ?? '',
    type: row.alert_type,
    severity: row.severity,
    title: row.title,
    description: row.description,
    metricName: row.metric_name,
    metricValue: row.metric_value,
    thresholdValue: row.threshold_value,
    isResolved: row.is_resolved,
    createdAt: row.created_at, // string — ver nota de topo
    action: row.action_url
      ? { type: 'link', label: 'Ver detalhes', url: row.action_url }
      : null,
  }
}

// ── Base query — orbit.alerts ─────────────────────────────────────────────
function orbitBaseQuery() {
  return supabase
    .from('alerts') // orbit.alerts
    .select(
      `
      id, client_id, alert_type, severity, title, description,
      metric_name, metric_value, threshold_value, action_url,
      is_resolved, created_at,
      clients ( name, handle )
    `
    )
    .eq('is_resolved', false) // padrão: apenas alertas abertos
    .order('created_at', { ascending: false })
}

// ── fetchAlerts ───────────────────────────────────────────────────────────
export async function fetchAlerts(filter?: AlertSeverity): Promise<Alert[]> {
  let query = orbitBaseQuery()
  if (filter !== undefined) query = query.eq('severity', filter)

  const { data, error } = await query.returns<OrbitAlertRow[]>()

  if (error) {
    throw new Error(`[alertsRepository] falha ao buscar orbit.alerts: ${error.message}`)
  }

  return (data ?? []).map(fromOrbitRow)
}

// ── fetchCriticalAlerts ───────────────────────────────────────────────────
export async function fetchCriticalAlerts(): Promise<Alert[]> {
  return fetchAlerts('critical')
}

// ── markAlertAsRead / markAlertResolved ───────────────────────────────────
// orbit.alerts usa is_resolved (boolean) + resolved_at (timestamp).
// Não existe mais fallback para public.alerts.read_at.
export async function markAlertAsRead(alertId: string): Promise<void> {
  const { error } = await supabase
    .from('alerts')
    .update({
      is_resolved: true,
      resolved_at: new Date().toISOString(),
    })
    .eq('id', alertId)

  if (error) {
    throw new Error(`[alertsRepository] falha ao marcar alerta como resolvido: ${error.message}`)
  }
}